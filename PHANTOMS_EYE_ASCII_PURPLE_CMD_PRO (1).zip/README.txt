PHANTOMS EYE — ASCII PURPLE CMD PRO
===================================

START:
1. Extract the ZIP into a folder.
2. Install Python 3.10+ if it is not already installed.
3. Double-click START_PHANTOMS_EYE.bat.

The launcher installs dnspython, which enables MX/NS/TXT/SOA/CAA/CNAME DNS lookups.
Without it, the program still works with the system socket resolver for A/AAAA and reverse lookups.

Included tools:
01 IP Deep Lookup
02 URL Deep Search
03 DNS Lookup
04 Reverse DNS
05 WHOIS / RDAP Lookup
06 HTTP Header Analysis
07 SSL/TLS Certificate
08 SHA-256 file hash
09 Base64 Analyzer
10 JSON Inspector
11 Email Header Analyzer
12 Local Log File Analyzer
13 Localhost Port Check (127.0.0.1 only)

IP/URL lookups attempt to collect as much public information as is available:
DNS records, resolved addresses, approximate geo-IP, RDAP registration/network data,
HTTP status and response headers, TLS certificate details, HTML metadata and previews
of common public files. Availability depends on DNS responses, the target server, network
access, and third-party APIs. Missing information and errors are shown rather than invented.

Notes:
- Geo-IP is approximate and can identify a provider/datacenter rather than a person's location.
- Missing security headers are not by themselves proof of a vulnerability.
- Public RDAP/geo-IP services can rate-limit requests or change their fields.
- Only ordinary public DNS, RDAP, HTTP and TLS requests are performed.
- The port checker only checks localhost (127.0.0.1), not remote systems.
- Use the toolkit only for lawful, authorized defensive analysis.
