#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PHANTOMS EYE — ASCII PURPLE CMD PRO
Passive/public-information lookup toolkit. Use only on systems and targets you are
authorized to inspect. Network calls are ordinary DNS/RDAP/HTTP/TLS requests.
"""
from __future__ import annotations
import base64, hashlib, json, os, re, socket, ssl, sys, time, urllib.error, urllib.parse, urllib.request
from datetime import datetime, timezone
from pathlib import Path

try:
    import dns.resolver
    import dns.reversename
    HAS_DNSPYTHON = True
except ImportError:
    HAS_DNSPYTHON = False

PURPLE = "\033[95m"
MAGENTA = "\033[35m"
CYAN = "\033[96m"
BLUE = "\033[94m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
WHITE = "\033[97m"
DIM = "\033[90m"
RESET = "\033[0m"
CLEAR = "\033[2J\033[H"

ASCII_ART = r""" .                                         .:+%@@@@@@@@#=...        .        .     .            .  .
 .                             .       .-%@@@@@@@@@@@@@@@@@@*:.                        .            
   .                                ..+@@@@@@@@@@@@@@@@@@@@@@@@+..               .           .      
              .                   ..=@@@@@@@@@@@@@@@@@@@@@@@@@@@@*..                               .
      .                   .      .:%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@-.           . .    .        .   
                .        .      .=@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@+.                              
   .  .                  .    ..=@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@-..                            
         .                  ..*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@=.        .    .              
 .              .           .#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@+.                    .      
        .                  .+@@@@@@@@@@@@@@@@@@#*@@@@@@@@@@@@@@@@@@@@@@@-..                  .      
                           .@@@@@@@@@@@@@@@@@@@.+@@@@@@@@@@@@@@@@@@@@@@@*.                       .  
 .  . .   .     .        ..:%@@@@@@@@@@@@@@@@@-.=@@@@@@@@+=@@@@@@@@@@@@@%.            .         .   
       .                .....:::...:.:#@@@@@@*:.+@@@@@@@%.:#@@@@@@@@@@@@@..                         
  .                   . .....:....=@@@@@@@@@+...+@@@@@@@-...%@@@@@@@@@@@%.          .               
               .        .......::--@@@@@@@@#....+@@@@@@+.  ..%@@@@@@@@@@#.                 .        
                        ... . ..+@**@@@@@%==....+@%@@@#.......%@@@@@@@@@*.                          
   .                .   ..      =-.=@@@@%%@#@#-.+#*@@@:...+@@@@@@@@@@@@@+.         .      .         
                      ....      ..:@@@@@@-=+@@#..-:@@*...+.#@@*@@@@@@@@@+.                          
    .       .   .    .....    . ...#@@@=*.@@@@#.  .-#=  .+@#%%:=#@@@%#@@+.                          
               ......... .  ....#+.+@@@:..:*-=:.   ..-....+++:..=@@@##@@+.                          
      .       ...       .....=@@@@:+@@@-.                  .    :@@@%@@@*.                          
       ......       . ...:..=@@@@@%+@@@+.         .             =@@@@@@@*.            .             
....              .......  .@@@@@@**@@@%.                     ..#@@@@@@@@.   .  .  .       .        
....          .......      -@@@@@@-+@@@#..       ... .        ..%@@@@@@@@-.     .     .     .       
             ...    .    ..#@@@@@@.-@@@#....     .:.....    ....%@@@@@@@@#.                         
       ....              .-@@@@@@@..#@@@....... .  ...  .... ...+@@@@@@@@%.                      .  
  .    ....     .        .#@@@@@##. .#@@=.  .....      .....  .=-@@%@@@@@@-           .    .        
     .:.....-.... ...   .:@@@%@@:+.  .+@%. .....::....:....   ..+@+%@@@@@@#.     .                  
   .....  ..*@@@@@@@@@@@@@@@@@@%.+.. ...-%................    ..*%.*@@@@@@@:.            .      .   
       .   .+@@@@@@@@@@@@@@@@@@@@@@@%#=..... ..   .......     ...*.+@@@@@@@*.      .                
... .      .=@@@@@@@@@@@@@@@@@@@@@@@@@@@@:..           ...      ...-@@@@@@@@..     .                
............-@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%-...          .....     .%@@@@@@@+..  .  .           .   
  ......:...:@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*:............-%@@#=--:-@@@@@@@%..            .        
   .  .  ...+@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%%#####%@@@@@@@@@@@@@@@@@@@@:.                     
 .         :@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@+.                 .   
           :@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@.      .              
           -@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@:.                    
           -@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@-.               .    
          .-@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@-            .        
 .         :@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@-                     
           :@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@:         .           
           .....+@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@: .            .      
         ..   .:@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@.     .               
              .*@@@@@@=:@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%.        .       .    
 .     .     .:@@@@@@@..=@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@.  .                . 
      .      .*@@@@@@*. .@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@-.                    
      .     .:@@@@@@@-  .+@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*.                  . 
            .+@@@@@@#.  .:@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@-.   .               
    .       .#@@@@@@-    .%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@.                 . 
            .%@@@@@@..   .#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@+.                 .
   .       .:@@@@@@#.    .*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@:.             .   
            -@@@@@@*.    .#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%..               .
     .     .=@@@@@@*.   ..%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*.          .      
.     .    .*@@@@@@+.   ..@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%+::.=@@*....                 
.  .       .#@@@@@@+.   .-@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@=:::...-@@.                  .  """

TOOLS = [
    ("IP Deep Lookup", "Maximum public information for an IP address"),
    ("URL Deep Search", "Maximum public information for a URL/domain"),
    ("DNS Lookup", "A/AAAA/CNAME/MX/NS/TXT/SOA/CAA where available"),
    ("Reverse DNS", "PTR / reverse hostname lookup"),
    ("WHOIS / RDAP Lookup", "Public registration and network allocation data"),
    ("HTTP Header Analysis", "Status, redirect chain, timings and response headers"),
    ("SSL/TLS Certificate", "Certificate identity, SANs, dates and fingerprint"),
    ("Hash Analyzer (SHA-256)", "Hash a local file"),
    ("Base64 Analyzer", "Encode/decode Base64 text"),
    ("JSON Inspector", "Validate and pretty-print JSON"),
    ("Email Header Analyzer", "Extract routing and authentication hints from pasted headers"),
    ("Log File Analyzer", "Summarize common errors and suspicious patterns in a local log"),
    ("Port Check (Localhost)", "Check selected ports on your own computer only"),
]

def pause():
    input(f"\n{DIM}Press Enter to continue...{RESET}")

def banner():
    print(PURPLE + "╔" + "═"*76 + "╗")
    print("║  👁 PHANTOMS EYE — ASCII PURPLE CMD PRO".ljust(77) + "║")
    print("╚" + "═"*76 + "╝" + RESET)

def show_art_startup():
    for i in range(3):
        print(CLEAR, end="")
        print(PURPLE + ASCII_ART + RESET)
        print(MAGENTA + f"\n      PHANTOMS EYE  •  STARTUP SEQUENCE {i+1}/3" + RESET)
        time.sleep(1)
        if i < 2:
            print(CLEAR, end="")
            time.sleep(0.35)

def frame(title, body):
    print(PURPLE + "\n┌─ " + title + " " + "─"*max(2, 68-len(title)) + RESET)
    print(body)
    print(PURPLE + "└" + "─"*74 + RESET)

def request(url, method="GET", headers=None, timeout=12, limit=2_000_000):
    req = urllib.request.Request(url, method=method, headers=headers or {
        "User-Agent": "PhantomsEye/1.0 (passive public-information lookup)",
        "Accept": "*/*",
    })
    started = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = resp.read(limit + 1)
            return {"ok": True, "status": resp.status, "final_url": resp.geturl(),
                    "headers": dict(resp.headers.items()), "body": data[:limit],
                    "truncated": len(data) > limit,
                    "elapsed_ms": round((time.perf_counter()-started)*1000, 2)}
    except urllib.error.HTTPError as e:
        body = b""
        try: body = e.read(limit)
        except Exception: pass
        return {"ok": False, "status": e.code, "final_url": e.geturl(),
                "headers": dict(e.headers.items()) if e.headers else {},
                "body": body, "error": str(e),
                "elapsed_ms": round((time.perf_counter()-started)*1000, 2)}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}",
                "elapsed_ms": round((time.perf_counter()-started)*1000, 2)}

def json_api(url):
    r = request(url, headers={"User-Agent":"PhantomsEye/1.0", "Accept":"application/json"})
    if r.get("body"):
        try: r["json"] = json.loads(r["body"].decode("utf-8", "replace"))
        except Exception: pass
    return r

def print_json(label, obj):
    print(CYAN + f"\n[{label}]" + RESET)
    print(json.dumps(obj, indent=2, ensure_ascii=False, default=str))

def safe_host(value):
    value = value.strip()
    if not value: raise ValueError("Keine Eingabe.")
    if "://" not in value:
        value = "https://" + value
    p = urllib.parse.urlsplit(value)
    if not p.hostname: raise ValueError("Kein gültiger Hostname in der Eingabe.")
    return value, p

def dns_records(host):
    result = {"hostname": host, "resolver": "dnspython" if HAS_DNSPYTHON else "system socket fallback", "records": {}}
    if HAS_DNSPYTHON:
        for typ in ("A","AAAA","CNAME","MX","NS","TXT","SOA","CAA"):
            try:
                ans = dns.resolver.resolve(host, typ, lifetime=4)
                result["records"][typ] = [{"value": r.to_text(), "ttl": ans.rrset.ttl} for r in ans]
            except Exception as e:
                result["records"][typ] = {"unavailable": str(e)}
    else:
        for family, typ in ((socket.AF_INET,"A"), (socket.AF_INET6,"AAAA")):
            try:
                vals = sorted({x[4][0] for x in socket.getaddrinfo(host, None, family, socket.SOCK_STREAM)})
                result["records"][typ] = vals
            except Exception as e:
                result["records"][typ] = {"unavailable": str(e)}
        result["records"]["other_record_types"] = "Install dnspython to query MX/NS/TXT/SOA/CAA/CNAME and TTL."
    try:
        result["records"]["system_reverse"] = sorted({socket.gethostbyaddr(x[4][0])[0] for x in socket.getaddrinfo(host, None) if x[0] in (socket.AF_INET, socket.AF_INET6)})
    except Exception as e:
        result["records"]["system_reverse"] = {"unavailable": str(e)}
    return result

def rdap_lookup(target, is_ip=False):
    urls = []
    if is_ip:
        urls = [f"https://rdap.org/ip/{urllib.parse.quote(target, safe=':./')}"]
    else:
        urls = [f"https://rdap.org/domain/{urllib.parse.quote(target)}"]
    for u in urls:
        r = json_api(u)
        if r.get("json") is not None:
            return {"source": u, "http_status": r.get("status"), "data": r["json"]}
        last = {"source": u, "http_status": r.get("status"), "error": r.get("error", "RDAP returned no JSON")}
    return last

def geo_ip(ip):
    # Public IP metadata endpoint; approximate and provider-dependent.
    try:
        obj = json_api("http://ip-api.com/json/" + urllib.parse.quote(ip) +
                       "?fields=status,message,continent,continentCode,country,countryCode,region,regionName,city,district,zip,lat,lon,timezone,offset,currency,isp,org,as,asname,reverse,mobile,proxy,hosting,query")
        return {"source":"ip-api.com (approximate geo-IP; provider response)", "data":obj.get("json", obj.get("error"))}
    except Exception as e: return {"error":str(e)}

def tls_info(host, port=443):
    out = {"host":host, "port":port}
    try:
        ctx = ssl.create_default_context()
        with socket.create_connection((host, port), timeout=8) as sock:
            with ctx.wrap_socket(sock, server_hostname=host) as ss:
                cert = ss.getpeercert()
                der = ss.getpeercert(binary_form=True)
                out.update({"tls_version":ss.version(), "cipher":ss.cipher(),
                            "certificate":cert,
                            "sha256_fingerprint":hashlib.sha256(der).hexdigest().upper(),
                            "certificate_bytes":len(der)})
    except Exception as e: out["error"] = f"{type(e).__name__}: {e}"
    return out

def parse_html(body, final_url):
    html = body.decode("utf-8", "replace")
    def meta(name):
        pat = r'<meta\b[^>]*(?:name|property)\s*=\s*["\']' + re.escape(name) + r'["\'][^>]*>'
        m = re.search(pat, html, re.I)
        if not m: return None
        c = re.search(r'content\s*=\s*["\']([^"\']*)', m.group(0), re.I)
        return c.group(1) if c else m.group(0)
    title = re.search(r"<title[^>]*>(.*?)</title\s*>", html, re.I|re.S)
    lang = re.search(r"<html\b[^>]*\blang\s*=\s*['\"]([^'\"]+)", html, re.I)
    canonical = re.search(r'<link\b[^>]*rel\s*=\s*["\']canonical["\'][^>]*href\s*=\s*["\']([^"\']+)', html, re.I)
    links = re.findall(r'<a\b[^>]*href\s*=\s*["\']([^"\']+)', html, re.I)
    return {"title": re.sub(r"\s+"," ",title.group(1)).strip() if title else None,
            "language":lang.group(1) if lang else None,
            "description":meta("description"), "keywords":meta("keywords"),
            "robots":meta("robots"), "canonical":urllib.parse.urljoin(final_url, canonical.group(1)) if canonical else None,
            "og_title":meta("og:title"), "og_description":meta("og:description"),
            "og_site_name":meta("og:site_name"), "og_type":meta("og:type"),
            "twitter_card":meta("twitter:card"), "twitter_title":meta("twitter:title"),
            "links_found":len(links), "sample_links":[urllib.parse.urljoin(final_url,x) for x in links[:100]],
            "html_bytes_analyzed":len(body)}

def security_header_report(headers):
    wanted = ["Strict-Transport-Security","Content-Security-Policy","X-Content-Type-Options",
              "X-Frame-Options","Referrer-Policy","Permissions-Policy",
              "Cross-Origin-Opener-Policy","Cross-Origin-Resource-Policy",
              "Cross-Origin-Embedder-Policy","Content-Type","Content-Length",
              "Server","Date","Last-Modified","Cache-Control","ETag","Vary",
              "Accept-Ranges","Content-Encoding","Set-Cookie","Location","Link"]
    lower = {k.lower():v for k,v in headers.items()}
    return {h:lower.get(h.lower(), "NOT PRESENT in this response") for h in wanted}

def url_deep_search():
    raw = input(f"{CYAN}URL / Domain: {RESET}").strip()
    try: normalized, p = safe_host(raw)
    except Exception as e: print(RED+str(e)+RESET); return
    host = p.hostname
    print(MAGENTA + "\n[1/8] URL identification" + RESET)
    info = {"input":raw,"normalized_url":normalized,"scheme":p.scheme,"hostname":host,
            "port":p.port or (443 if p.scheme=="https" else 80),"path":p.path or "/",
            "query":p.query or None,"fragment":p.fragment or None,
            "username_present":bool(p.username),"password_present":bool(p.password),
            "IDNA_hostname":host.encode("idna").decode("ascii") if host else None,
            "TLD":host.rsplit(".",1)[-1] if "." in host else None}
    print_json("URL DETAILS", info)
    print(MAGENTA + "\n[2/8] DNS records" + RESET); print_json("DNS", dns_records(host))
    ips = []
    try:
        for x in socket.getaddrinfo(host, None):
            ip = x[4][0]
            if ip not in ips: ips.append(ip)
    except Exception as e: print(RED+f"IP resolution error: {e}"+RESET)
    print_json("RESOLVED IP ADDRESSES", ips)
    print(MAGENTA + "\n[3/8] RDAP / registration" + RESET)
    print_json("DOMAIN RDAP", rdap_lookup(host, False))
    print(MAGENTA + "\n[4/8] Geo-IP and IP RDAP" + RESET)
    for ip in ips:
        print_json("IP: "+ip, {"classification":{"version":"IPv6" if ":" in ip else "IPv4",
                    "is_global":__import__("ipaddress").ip_address(ip).is_global,
                    "is_private":__import__("ipaddress").ip_address(ip).is_private,
                    "is_reserved":__import__("ipaddress").ip_address(ip).is_reserved},
                    "geo_ip":geo_ip(ip),"rdap":rdap_lookup(ip, True)})
    print(MAGENTA + "\n[5/8] HTTP response and headers" + RESET)
    http_url = normalized
    result = request(http_url, headers={"User-Agent":"Mozilla/5.0 (compatible; PhantomsEye/1.0)",
                                        "Accept":"text/html,application/xhtml+xml,*/*"})
    # If HTTPS fails due to certificate/connection problems, do not silently downgrade to HTTP.
    http_summary = {k:v for k,v in result.items() if k not in ("body",)}
    if result.get("headers"): http_summary["selected_security_headers"] = security_header_report(result["headers"])
    print_json("HTTP RESPONSE", http_summary)
    if result.get("headers"): print_json("ALL RESPONSE HEADERS", result["headers"])
    print(MAGENTA + "\n[6/8] TLS certificate" + RESET)
    print_json("TLS", tls_info(host, p.port or 443) if p.scheme=="https" else {"note":"Input uses HTTP; TLS checked only for HTTPS URLs."})
    print(MAGENTA + "\n[7/8] Page metadata and public standard files" + RESET)
    if result.get("body"):
        print_json("PAGE METADATA", parse_html(result["body"], result.get("final_url", normalized)))
    base = f"{p.scheme}://{host}" + (f":{p.port}" if p.port else "")
    for path in ("/robots.txt","/sitemap.xml","/security.txt","/.well-known/security.txt","/manifest.json","/favicon.ico"):
        rr = request(urllib.parse.urljoin(base+"/", path.lstrip("/")), timeout=5, limit=120_000)
        print_json(path, {"status":rr.get("status"),"final_url":rr.get("final_url"),
                          "content_type":rr.get("headers",{}).get("Content-Type"),
                          "bytes":len(rr.get("body",b"")),"error":rr.get("error"),
                          "preview":rr.get("body",b"")[:1500].decode("utf-8","replace") if rr.get("body") else None})
    print(MAGENTA + "\n[8/8] Completion notes" + RESET)
    print("• Geo-IP is approximate and can point to a provider/datacenter.")
    print("• Missing security headers are observations, not automatic proof of a vulnerability.")
    print("• Third-party API fields depend on that provider and may be missing or rate-limited.")
    print("• Only public/passive information and ordinary web requests were used.")

def ip_deep_lookup():
    raw = input(f"{CYAN}IP address: {RESET}").strip()
    try:
        import ipaddress
        ip = ipaddress.ip_address(raw)
    except ValueError:
        print(RED+"Please enter a valid IPv4 or IPv6 address."+RESET); return
    data = {"input":raw,"version":ip.version,"compressed":getattr(ip,"compressed",str(ip)),
            "exploded":getattr(ip,"exploded",str(ip)),"is_global":ip.is_global,
            "is_private":ip.is_private,"is_reserved":ip.is_reserved,"is_loopback":ip.is_loopback,
            "is_link_local":ip.is_link_local,"is_multicast":ip.is_multicast,
            "is_unspecified":ip.is_unspecified,"reverse_pointer":ip.reverse_pointer}
    print_json("IP CLASSIFICATION",data)
    try: print_json("REVERSE DNS", {"hostname":socket.gethostbyaddr(raw)[0],"aliases":socket.gethostbyaddr(raw)[1]})
    except Exception as e: print_json("REVERSE DNS",{"unavailable":str(e)})
    print_json("GEO-IP (APPROXIMATE)",geo_ip(raw))
    print_json("RDAP / NETWORK REGISTRATION",rdap_lookup(raw,True))
    print(CYAN+"\nNote: geographic results are estimates; private/reserved IPs may not have public registry data."+RESET)

def dns_tool():
    host=input(f"{CYAN}Hostname/domain: {RESET}").strip().split("/")[0]
    if not host: return
    print_json("DNS RECORDS",dns_records(host))

def reverse_dns_tool():
    target=input(f"{CYAN}IP address or hostname: {RESET}").strip()
    try:
        ip=__import__("ipaddress").ip_address(target)
        print_json("PTR", {"ip":target,"reverse_pointer":ip.reverse_pointer,"result":socket.gethostbyaddr(target)})
    except ValueError:
        try: print_json("HOST LOOKUP",{"host":target,"addresses":sorted({x[4][0] for x in socket.getaddrinfo(target,None)})})
        except Exception as e: print_json("LOOKUP ERROR",{"error":str(e)})
    except Exception as e: print_json("LOOKUP ERROR",{"error":str(e)})

def rdap_tool():
    target=input(f"{CYAN}IP or domain: {RESET}").strip()
    try:
        import ipaddress
        ipaddress.ip_address(target); is_ip=True
    except ValueError: is_ip=False
    print_json("RDAP",rdap_lookup(target,is_ip))

def http_tool():
    raw=input(f"{CYAN}URL: {RESET}").strip()
    try: u,p=safe_host(raw)
    except Exception as e: print(RED+str(e)+RESET); return
    r=request(u)
    print_json("HTTP RESULT",{k:v for k,v in r.items() if k!="body"})
    if r.get("headers"): print_json("ALL HEADERS",r["headers"])
    if r.get("body"): print("Body preview:\n"+r["body"][:1000].decode("utf-8","replace"))

def tls_tool():
    raw=input(f"{CYAN}Hostname [example.com]: {RESET}").strip()
    if not raw: return
    if "://" in raw:
        _,p=safe_host(raw); host=p.hostname; port=p.port or 443
    else: host=raw.split(":")[0]; port=int(raw.rsplit(":",1)[1]) if ":" in raw and raw.count(":")==1 else 443
    print_json("TLS",tls_info(host,port))

def hash_tool():
    raw=input(f"{CYAN}Local file path: {RESET}").strip().strip('"')
    try:
        h=hashlib.sha256(); size=0
        with open(raw,"rb") as f:
            for chunk in iter(lambda:f.read(1024*1024),b""): h.update(chunk); size+=len(chunk)
        print_json("SHA-256",{"file":raw,"bytes":size,"sha256":h.hexdigest()})
    except Exception as e: print(RED+str(e)+RESET)

def base64_tool():
    mode=input("Encode or decode [e/d]: ").strip().lower()
    value=input("Text: ")
    try:
        if mode=="d":
            decoded=base64.b64decode(value,validate=True)
            print_json("BASE64 DECODE",{"bytes":len(decoded),"utf8":decoded.decode("utf-8","replace"),"hex":decoded.hex()})
        else: print(base64.b64encode(value.encode()).decode())
    except Exception as e: print(RED+f"Base64 error: {e}"+RESET)

def json_tool():
    value=input("Paste one-line JSON: ")
    try: print(json.dumps(json.loads(value),indent=2,ensure_ascii=False))
    except Exception as e: print(RED+f"JSON invalid: {e}"+RESET)

def email_header_tool():
    print("Paste email headers; enter a blank line to finish:")
    lines=[]
    while True:
        line=input()
        if not line: break
        lines.append(line)
    raw="\n".join(lines)
    fields={}
    for line in raw.splitlines():
        if ":" in line and not line[:1].isspace():
            k,v=line.split(":",1); fields.setdefault(k.strip(),[]).append(v.strip())
    auth=[(k,v) for k,v in fields.items() if k.lower() in ("received","authentication-results","received-spf","dkim-signature","return-path","from","reply-to","message-id","date","subject")]
    print_json("EMAIL HEADER SUMMARY",{"parsed_fields":fields,"key_fields":dict(auth),
      "notes":["Header text can be forged; authentication results depend on the receiving system.",
               "Do not paste private or sensitive messages into shared environments."]})

def log_tool():
    path=input("Local log file path: ").strip().strip('"')
    try:
        lines=Path(path).read_text(encoding="utf-8",errors="replace").splitlines()
        pats={"error":r"\berror\b|\bexception\b|\bfail(ed|ure)?\b",
              "warning":r"\bwarn(ing)?\b",
              "auth":r"login|logon|authentication|unauthorized|forbidden|failed password",
              "network":r"timeout|connection refused|reset by peer|dns"}
        summary={k:sum(bool(re.search(p,x,re.I)) for x in lines) for k,p in pats.items()}
        print_json("LOG SUMMARY",{"file":path,"line_count":len(lines),"matches":summary,
          "matching_line_samples":[{"line":i+1,"text":line[:500]} for i,line in enumerate(lines) if any(re.search(p,line,re.I) for p in pats.values())][:100]})
    except Exception as e: print(RED+str(e)+RESET)

def localhost_ports():
    raw=input("Localhost ports, comma-separated [22,80,443,445,3389]: ").strip() or "22,80,443,445,3389"
    try: ports=sorted({int(x.strip()) for x in raw.split(",") if 1 <= int(x.strip()) <= 65535})
    except Exception: print(RED+"Invalid port list."+RESET); return
    results=[]
    for port in ports:
        s=socket.socket(); s.settimeout(.35)
        try: state="OPEN" if s.connect_ex(("127.0.0.1",port))==0 else "closed / filtered"
        except Exception as e: state=str(e)
        finally: s.close()
        results.append({"host":"127.0.0.1","port":port,"result":state})
    print_json("LOCALHOST ONLY",results)

ACTIONS = [ip_deep_lookup, url_deep_search, dns_tool, reverse_dns_tool, rdap_tool,
           http_tool, tls_tool, hash_tool, base64_tool, json_tool, email_header_tool,
           log_tool, localhost_ports]

def menu():
    while True:
        print(CLEAR, end="")
        banner()
        print(PURPLE+ASCII_ART+RESET)
        print(CYAN+"\n  MAIN MENU"+RESET)
        for i,(name,desc) in enumerate(TOOLS,1):
            print(f"  {MAGENTA}[{i:02d}]{RESET} {WHITE}{name:<25}{RESET} {DIM}{desc}{RESET}")
        print(f"\n{GREEN}PHANTOMS_EYE>{RESET} Enter tool number, 'help', 'clear', or 'exit'")
        choice=input(f"{MAGENTA}>>> {RESET}").strip().lower()
        if choice in ("exit","quit","q"): break
        if choice=="clear": continue
        if choice=="help":
            print("\nUse a number from 1–13. IP/URL lookups collect public DNS, RDAP, HTTP/TLS and metadata where available.")
            pause(); continue
        try:
            idx=int(choice)-1
            if 0 <= idx < len(ACTIONS):
                print(CLEAR,end=""); banner()
                try: ACTIONS[idx]()
                except KeyboardInterrupt: print(RED+"\nCancelled by user."+RESET)
                except Exception as e: print(RED+f"\nTool error: {type(e).__name__}: {e}"+RESET)
                pause()
            else: print(RED+"Unknown tool number."+RESET); time.sleep(.8)
        except ValueError:
            print(RED+"Enter a menu number or command."+RESET); time.sleep(.8)

def main():
    if os.name == "nt":
        os.system("")
        os.system("title PHANTOMS EYE -- ASCII PURPLE CMD PRO")
    show_art_startup()
    menu()
    print(PURPLE+"\nPHANTOMS EYE closed. Stay safe."+RESET)

if __name__ == "__main__":
    main()
